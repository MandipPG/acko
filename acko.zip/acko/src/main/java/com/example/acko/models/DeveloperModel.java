package com.example.acko.models;

import javax.persistence.*;
import java.util.Map;

@Entity
@Table(name = "developer")
public class DeveloperModel {


    @Id
    @GeneratedValue
    private long id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String phone_number;

    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumn(referencedColumnName = "id")
    private TeamModel teamId;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone_number() {
        return phone_number;
    }

    public void setPhone_number(String phone_number) {
        this.phone_number = phone_number;
    }

    public TeamModel getTeamId() {
        return teamId;
    }

    public void setTeamId(TeamModel teamId) {
        this.teamId = teamId;
    }

    public DeveloperModel() {};

    public DeveloperModel(TeamModel teamModel, Map<String, String> details) {
        this.teamId = teamModel;
        this.name = details.getOrDefault("name", "");
        this.phone_number = details.getOrDefault("phone_number", "");
    }

    @Override
    public String toString() {
        return "DeveloperModel{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", phone_number='" + phone_number + '\'' +
                ", teamId=" + teamId +
                '}';
    }
}

