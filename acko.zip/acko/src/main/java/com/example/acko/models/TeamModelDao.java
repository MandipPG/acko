package com.example.acko.models;

import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

@Transactional
public interface TeamModelDao extends  CrudRepository<TeamModel, Long> {

    public TeamModel getById(long teamId);

    public TeamModel getByName(String teamName);


}

