package com.example.acko.models;


import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface DeveloperModelDao extends CrudRepository<DeveloperModel, Long> {

    public List<DeveloperModel> getDeveloperModelByTeamId(String teamID);

}
