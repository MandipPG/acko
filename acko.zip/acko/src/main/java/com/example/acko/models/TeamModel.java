package com.example.acko.models;

import javax.persistence.*;

@Entity
@Table(name = "team")
public class TeamModel {

    @Id
    @GeneratedValue
    private long id;

    @Column(nullable = false)
    private String name;


    public String getName() {
        return name;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public TeamModel(){};

    @Override
    public String toString() {
        return "TeamModel{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                '}';
    }
}

