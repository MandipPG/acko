package com.example.acko.services;

import com.example.acko.models.DeveloperModelDao;
import com.example.acko.models.TeamModel;
import com.example.acko.models.TeamModelDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class TeamService {

    @Autowired
    TeamModelDao teamModelDao;

    @Autowired
    DeveloperModelDao developerModelDao;

    @Autowired
    SMSService smsService;

    @Transactional
    public Object createTeam(Map<String, Object> input) {
        Object response = "Team Name is not valid";
        String teamName = input.getOrDefault("team", null).toString();
        if (teamName != null && !teamName.isEmpty()) {
            response = "Team is already present";
            if (teamModelDao.getByName(teamName) == null) {
                TeamModel teamModel = new TeamModel();
                teamModel = teamModelDao.save(teamModel);
                response = teamModel.getId();

                List<Map<String, String>> developerList = (List<Map<String, String>>) input.getOrDefault("developers", new ArrayList());
                if (developerList.size() > 0) {
                    for (Map<String, String> developer : developerList) {
                        developerModelDao.save(new DeveloperModel(teamModel, developer));
                    }
                }
            }
        }
        return response;
    }

    public Object receiveAlert(String teamId) {
        Object response = "Receiving Alert Failed";
        if (teamId != null && !teamId.isEmpty()) {
            List<DeveloperModel> developerList = developerModelDao.getDeveloperModelByTeamId(teamId);
            if (developerList.size() > 0) {
                String phone_number = developerList.get(0).getPhone_number();
                // send SMS to this Phone_number
                // if SMS sent success fully then return SUCCESS else error msg;
                smsService.sendSMS(phone_number, "Your team got an alert regarding 5xx!");
            }
        }
        return response;
    }
}

