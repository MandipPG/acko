package com.example.acko.services;

import com.mashape.unirest.http.Unirest;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class SMSService {

    public Object sendSMS(String phone_number, String messageContent) {

        String url = "https://run.mocky.io/v3/fd99c100-f88a-4d70-aaf7-393dbbd5d99f";
        Map<String, Object> request = new HashMap<>();
        request.put("phone_number", phone_number);
        request.put("message", messageContent);
        Map<String, String> headers = new HashMap<>();
        headers.put("content-type", "application/json");
        Object response = "Sending SMS Failed";
        try {
            response =
                    Unirest.post(url).headers(headers).body(request).asString();
        } catch (Exception e) {
            response = e.getMessage();
        }

        return response;

    }
}

