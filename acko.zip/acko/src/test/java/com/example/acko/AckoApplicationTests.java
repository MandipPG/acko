package com.example.acko;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AckoApplicationTests {

	@Test
	void contextLoads() {
	}

}
